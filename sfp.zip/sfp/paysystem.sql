-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 05, 2019 at 09:08 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paysystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `detail` text NOT NULL,
  `delete_status` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `branch`, `address`, `detail`, `delete_status`) VALUES
(1, 'Githurai Branch', '1788 ', 'Hard work never fails.', '0'),
(2, 'Kawangware Branch', '4705 School Street', 'located at kawangware and it is the best', '0'),
(3, 'Kingswood School', '123 westlanda', 'this is the school to be', '0'),
(4, 'Marion Cross School', '22 Church road', 'Best and best', '0');

-- --------------------------------------------------------

--
-- Table structure for table `fees_transaction`
--

CREATE TABLE `fees_transaction` (
  `id` int(255) NOT NULL,
  `stdid` varchar(255) NOT NULL,
  `paid` int(255) NOT NULL,
  `submitdate` datetime NOT NULL,
  `transcation_remark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees_transaction`
--

INSERT INTO `fees_transaction` (`id`, `stdid`, `paid`, `submitdate`, `transcation_remark`) VALUES
(1, '1', 3000, '1993-11-04 00:00:00', 'Ensure you pay fees before endterm'),
(2, '2', 4500, '2003-11-12 00:00:00', ''),
(3, '1', 1200, '2018-11-27 00:00:00', ''),
(4, '2', 3000, '2018-11-13 00:00:00', ''),
(5, '1', 6800, '2018-11-22 00:00:00', ''),
(6, '3', 20000, '2019-11-13 00:00:00', ''),
(7, '3', 12000, '2019-11-13 00:00:00', ''),
(8, '4', 300, '2019-11-14 00:00:00', ''),
(9, '5', 20000, '2019-11-06 00:00:00', 'Pay before start of exams'),
(10, '6', 5000, '2019-11-07 00:00:00', ''),
(11, '7', 5000, '2019-11-13 00:00:00', ''),
(12, '7', 5000, '2019-11-14 00:00:00', ''),
(13, '3', 3000, '2019-11-30 00:00:00', 'Cleared Fees'),
(14, '8', 20, '2019-11-13 00:00:00', ''),
(15, '8', 980, '2019-11-19 00:00:00', ''),
(16, '9', 6, '2019-11-14 00:00:00', ''),
(17, '5', 56, '2019-11-13 00:00:00', ''),
(18, '5', 77, '2019-11-13 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `joindate` datetime NOT NULL,
  `about` text NOT NULL,
  `contact` varchar(255) NOT NULL,
  `fees` int(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `balance` int(255) NOT NULL,
  `delete_status` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `emailid`, `sname`, `joindate`, `about`, `contact`, `fees`, `branch`, `balance`, `delete_status`) VALUES
(1, 'dell@gmail.com', 'dell dells', '1993-11-04 00:00:00', 'from humble family', '0715109278', 11000, '1', 0, '1'),
(2, 'test@gmail.com', 'test', '2003-11-12 00:00:00', '', '0715109278', 45000, '3', 37500, '1'),
(3, 'johnk@gmail.com', 'John Kamau', '2019-11-13 00:00:00', 'International', '123456', 35000, '3', 0, '0'),
(4, '', '6363', '2019-11-14 00:00:00', '', '2242', 1000, '1', 700, '1'),
(5, 'enjoroge@gmail.com', 'Eliud Njoroge', '2019-11-06 00:00:00', '', '0725413212', 100000, '2', 79867, '0'),
(6, 'jkimeu@gmail.com', 'James Kimeu', '2019-11-07 00:00:00', '', '0723412543', 50000, '1', 45000, '0'),
(7, 'tyyty@ymail.com', 'dfsdfsdf', '2019-11-13 00:00:00', '', '123456', 100000, '2', 90000, '1'),
(8, '', 'fgddd', '2019-11-13 00:00:00', '', '655', 1000, '3', 0, '0'),
(9, '', 'ewew', '2019-11-14 00:00:00', '', '34', 55, '2', 49, '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `lastlogin` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `name`, `emailid`, `lastlogin`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Lewa', 'lewa@gmail.com', '0000-00-00 00:00:00'),
(2, 'test', '098f6bcd4621d373cade4e832627b4f6', 'test', 'test@gmail,com', '2018-11-27 01:14:24'),
(3, 'fabio', '123', 'Allan Nyatome', 'nyatome@gmail.com', '2019-11-09 12:06:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_transaction`
--
ALTER TABLE `fees_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fees_transaction`
--
ALTER TABLE `fees_transaction`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
